



export default function(pet){

}